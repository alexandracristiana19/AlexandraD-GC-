package com.example.laborator2;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import javax.microedition.khronos.opengles.GL10;
import javax.microedition.khronos.opengles.GL11;

public class Square {
    private FloatBuffer mFVertexBuffer;
    private ByteBuffer mColorBuffer;
    private ByteBuffer mIndexBuffer;

    // Nodurile pătratului
    private float[] vertices = {
            -0.5f, 0.5f, 0.0f,    // Vârful stânga sus
            -0.5f, -0.5f, 0.0f,   // Vârful stânga jos
            0.5f, -0.5f, 0.0f,    // Vârful dreapta jos
            0.5f, 0.5f, 0.0f      // Vârful dreapta sus
    };

    // Culorile RGBA: roșu deplin, partea stângă puțin estompată
    private byte maxColor = (byte) 255;
    private byte[] colors = {
            maxColor, 0, 0, (byte)128, // stânga sus - estompat
            maxColor, 0, 0, (byte)128, // stânga jos - estompat
            maxColor, 0, 0, maxColor,  // dreapta jos - complet
            maxColor, 0, 0, maxColor   // dreapta sus - complet
    };

    // Indicii triunghiurilor
    private byte[] indices = {0, 1, 2, 0, 2, 3};

    public Square() {
        // Vertex buffer
        ByteBuffer vbb = ByteBuffer.allocateDirect(vertices.length * 4);
        vbb.order(ByteOrder.nativeOrder());
        mFVertexBuffer = vbb.asFloatBuffer();
        mFVertexBuffer.put(vertices);
        mFVertexBuffer.position(0);

        // Color buffer
        mColorBuffer = ByteBuffer.allocateDirect(colors.length);
        mColorBuffer.put(colors);
        mColorBuffer.position(0);

        // Index buffer
        mIndexBuffer = ByteBuffer.allocateDirect(indices.length);
        mIndexBuffer.put(indices);
        mIndexBuffer.position(0);
    }

    public void draw(GL10 gl) {
        GL11 gl11 = (GL11) gl;

        gl11.glFrontFace(GL11.GL_CW); // triunghiurile față
        gl11.glVertexPointer(3, GL11.GL_FLOAT, 0, mFVertexBuffer);
        gl11.glColorPointer(4, GL11.GL_UNSIGNED_BYTE, 0, mColorBuffer);
        gl11.glDrawElements(GL11.GL_TRIANGLES, indices.length, GL11.GL_UNSIGNED_BYTE, mIndexBuffer);
        gl11.glFrontFace(GL11.GL_CCW); // reset la default
    }
}